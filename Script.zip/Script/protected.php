<?php
	session_start();
	include 'config.php';
	$alert=NULL;
	function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
		return $randomString;
	}
	$user_id=$_SESSION['user_id'];
	if(isset($_POST['generate'])){
		if(!$_POST['password']==''){
			$pass='yes';
		} else {
			$pass='no';
		}
		$link_gen=generateRandomString();
		$check_link=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM links WHERE link_id='".$link_gen."'"));
		if($check_link>=1){
			$link_gen="X".generateRandomString()."";
		} else {
			$link_gen=generateRandomString();
		}
		$link_rev=generateRandomString();
		$check_r_link=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM links WHERE remove_id='".$link_rev."'"));
		if($check_r_link>=1){
			$link_rev="X".generateRandomString()."";
		} else {
			$link_rev=generateRandomString();
		}
		$link_get=generateRandomString();
		$check_g_link=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM links WHERE get_id='".$link_get."'"));
		if($check_g_link>=1){
			$link_get="X".generateRandomString()."";
		} else {
			$link_get=generateRandomString();
		}
		$urls=mysqli_real_escape_string($conn,$_POST['urls']);
		$password=mysqli_real_escape_string($conn,$_POST['password']);
		$title=mysqli_real_escape_string($conn,$_POST['title']);
		$done_link=mysqli_query($conn,"INSERT INTO links (link_id,get_id,remove_id,urls,pass,password,title,user_id,captcha,date,status) VALUES ('".$link_gen."','".$link_get."','".$link_rev."','".$urls."','".$pass."','".$password."','".$title."','".$user_id."','".$_POST['captcha']."','".date('Y-m-d')."','active')");
		if($done_link){
			$alert='<div class="alert alert-success"><i class="fa fa-check"></i>&nbsp;Success, Link has been protected</div>';
		} else {
			$alert='<div class="alert alert-danger"><i class="fa fa-remove"></i>&nbsp;Something is wrong, try again</div>';
			$st='none';
		}
	} else {
		header('location:/');
	}
		$settings=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM settings WHERE id='1'"));
		$ads=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM ads WHERE id='1'"));
?>
<html>
	<head>
		<title><?Php echo $settings['site_name'];?> - Share your link now</title>
		<!-- meta tags-->
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Make your link safe using Link Protector" />
		<meta name="keywords" content="link, short, protector" />
		<meta name="author" content="Rohit Chauhan" />
		<meta name="robots" content="nofollow, noindex" />
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />
		<link rel="stylesheet" href="assets/fonts/css/font-awesome.min.css">
		<link rel="icon" href="favicon.png" sizes="16x16" type="image/png">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/jquery-1.9.1.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/bootstrap.bundle.min.js"></script>
	</head>
	<body class="bg-light">
		<?php include 'header.php';?>
		<div class="container">
		<br>
		<br>
		<div class="card p-4">
			<h5><i style="color:green;" class="fa fa-link"></i>&nbsp;YOUR PROTECTED LINKS</h5>
			<hr>
			<?php echo $alert;?>
			<div style="display:<?php echo $st;?>;">
			<div class="well p-2">
				<h3 style="font-size:16px;" class="badge badge-success">Protected link</h3>&nbsp;&nbsp;&nbsp;&nbsp;
				<a  style="font-size:18px;" href="get/<?php echo $link_get;?>" target="_blank">http://<?php echo $_SERVER['HTTP_HOST'];?>/get/<?php echo $link_get;?></a>
			</div>
			<br>
			<div class="well p-2">
				<h3 style="font-size:16px;" class="badge badge-warning">Remove link</h3>&nbsp;&nbsp;&nbsp;&nbsp;
				<a  style="font-size:18px;" href="del/<?php echo $link_rev;?>" target="_blank">http://<?php echo $_SERVER['HTTP_HOST'];?>/del/<?php echo $link_rev;?></a>
			</div>
			<?php
	if($check_ip>=2){
		echo '';
	} else {
		echo '
			<form id="insertformPro" action="ad_click.php" method="post">
			<input type="hidden" name="ip" value="'.$users_ip.'"/>
			<div id="sendPro">
				<div id="resultPro">'.$ads['ads2'].'</h4>
			</div>
			</form>
		';
	}
?>
			</div>
			
		</div>
		<br>
		</div>
		<br>
		<br>
		<br>
			<?php include 'footer.php';?>	
	</body>
	<script>
		$('#insertformPro').submit(function(){
			return false;
		});
		$('#sendPro').click(function(){
			$.post(		
				$('#insertformPro').attr('action'),
				$('#insertformPro :input').serializeArray(),
				function(result){
					$('#resultPro').html(result);
				}
			);
		});
			$('#insertformHead').submit(function(){
			return false;
		});
		$('#sendHead').click(function(){
			$.post(		
				$('#insertformHead').attr('action'),
				$('#insertformHead :input').serializeArray(),
				function(result){
					$('#resultHead').html(result);
				}
			);
		});
		
		$('#insertformFoot').submit(function(){
			return false;
		});
		$('#sendFoot').click(function(){
			$.post(		
				$('#insertformFoot').attr('action'),
				$('#insertformFoot :input').serializeArray(),
				function(result){
					$('#resultFoot').html(result);
				}
			);
		});
	</script>
</html>