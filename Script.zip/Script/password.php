<?php
	session_start();
	include 'config.php';
	$alert=NULL;
	
	if(!$_SESSION['user_id']){
	header('location:login.php');	
	}	
$ads=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM ads WHERE id='1'"));
	$logged_user=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM users WHERE user_id='".$_SESSION['user_id']."'"));

if(isset($_POST['pass'])){
	$cr=md5($_POST['cr_password']);
	if($cr==$logged_user['password']) {
		if($_POST['new_password']==$_POST['c_new_password']) {
			$pss=mysqli_real_escape_string($conn,md5($_POST['new_password']));
			$check=mysqli_query($conn,"UPDATE users SET password='".$pss."' WHERE user_id='".$_SESSION['user_id']."'");
			if($check){
				$alert='<div class="alert alert-success">Password Changed!<meta http-equiv="refresh" content="1" /></div>';
			} else {
				$alert='<div class="alert alert-danger">Password Change Failed, Try Again Later!</div>';
			}
		} else {
			$alert='<div class="alert alert-danger">Password Not Match!</div>';
		}
	} else {
		$alert='<div class="alert alert-danger">Wrong Current Password!</div>';
	}
}
?>
<html>
	<head>
		<title>Change Password</title>
		<!-- meta tags-->
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Make your link safe using Link Protector" />
		<meta name="keywords" content="link, short, protector" />
		<meta name="author" content="Rohit Chauhan" />
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />
		<link rel="stylesheet" href="assets/fonts/css/font-awesome.min.css">
		<link rel="icon" href="favicon.png" sizes="16x16" type="image/png">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/jquery-1.9.1.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/bootstrap.bundle.min.js"></script>
	</head>
	<body class="bg-light">
		<?php include 'header.php';?>
		<div class="container">
		<br>
		<form action="" method="post">
		<?php echo $alert;?>
		<div class="card p-3">
			<h4><i class="fa fa-lock"></i>&nbsp;Change Password</h4>
			<hr>
			<div class="row">
				<div style="text-align:right;" class="col-3">
					<h6>Current Password:</h6>
				</div>
				<div class="col-8">
					<input type="password" name="cr_password" class="form-control" placeholder="Current Password"/>
				</div>
			</div>
			<br>
			<div class="row">
				<div style="text-align:right;" class="col-3">
					<h6>New Password:</h6>
				</div>
				<div class="col-8">
				<input type="password" name="new_password" class="form-control" placeholder="New Password"/>
				</div>
			</div>
			<br>
			<div class="row">
				<div style="text-align:right;" class="col-3">
					<h6>Confirm New Password:</h6>
				</div>
				<div class="col-8">
					<input type="password" name="c_new_password" class="form-control" placeholder="Confirm New Password"/>
				</div>
			</div>
			<br>
			<div class="row">
				<div style="text-align:right;" class="col-3">
				</div>
				<div class="col-8">
					<input type="submit" name="pass" class="btn btn-success" value="CHANGE PASSWORD"/>
				</div>
			</div>
			<br>
		</div>
		<br>
		</form>
		</div>
			<?php include 'footer.php';?>	
	</body>
</html>