<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
  <div class="container">
    <a class="navbar-brand" href="#">
          <a href="/"><img style="width:150px;height:50px;" src="<?php if(basename($_SERVER['PHP_SELF'])=='get.php' || basename($_SERVER['PHP_SELF'])=='view.php' || basename($_SERVER['PHP_SELF'])=='del.php'){echo'../assets/img/logo.png';} else {echo'assets/img/logo.png';}?>" alt="Logo"></a>
        </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
	<?php if($_SESSION['user_id']) { ?>
      <a class="nav-item btn btn-danger <?php if(basename($_SERVER['PHP_SELF'])=='user.php'){echo'active';}?>" href="/user.php"><i class="fa fa-user"></i>&nbsp;Account</a>
	   &nbsp;
	 &nbsp;
      <a class="nav-item btn btn-danger <?php if(basename($_SERVER['PHP_SELF'])=='password.php'){echo'active';}?>" href="/password.php"><i class="fa fa-lock"></i>&nbsp;Password</a>
	   &nbsp;
	 &nbsp;
      <a class="nav-item btn btn-danger <?php if(basename($_SERVER['PHP_SELF'])=='links.php'){echo'active';}?>" href="/links.php"><i class="fa fa-link"></i>&nbsp;Manage Links</a>
	   &nbsp;
	 &nbsp;
      <a class="nav-item btn btn-danger <?php if(basename($_SERVER['PHP_SELF'])=='payment.php'){echo'active';}?>" href="/payment.php"><i class="fa fa-dollar"></i>&nbsp;Payment</a>
	   &nbsp;
	 &nbsp;
	    <a class="nav-item btn btn-danger" href="/logout.php"><i class="fa fa-sign-out"></i>Logout</a>
	<?php } else { ?>
	
	 <a class="nav-item btn btn-danger <?php if(basename($_SERVER['PHP_SELF'])=='login.php'){echo'active';}?>" href="/login.php"><i class="fa fa-user"></i>&nbsp;Login</a>
	 &nbsp;
	 &nbsp;
	 <a class="nav-item btn btn-danger <?php if(basename($_SERVER['PHP_SELF'])=='signup.php'){echo'active';}?>" href="/signup.php"><i class="fa fa-user"></i>&nbsp;Signup</a>
	  
	<?php } ?>
      </ul>
    </div>
  </div>
</nav>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="/money.php">Earn Money</a>
      <a class="nav-item nav-link" href="/faq.php">Faq</a>
      <a class="nav-item nav-link" href="/policy.php">Terms and Policy</a>
      <a class="nav-item nav-link" href="/dmca.php">DMCA Policy</a>
    </div>
  </div>
</nav>
<?php
	if($check_ip>=2){
		echo '';
	} else {
		echo '
			<form id="insertformHead" action="ad_click.php" method="post">
			<input type="hidden" name="ip" value="'.$users_ip.'"/>
			<div id="sendHead">
				<div id="resultHead">'.$ads['ads1'].'</h4>
			</div>
			</form>
		';
	}
?>