<?php
	session_start();
	include 'config.php';
	$alert=NULL;
	
	if(!$_SESSION['user_id']){
	header('location:login.php');	
	}	
$ads=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM ads WHERE id='1'"));
	$logged_user=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM users WHERE user_id='".$_SESSION['user_id']."'"));
	
	$ttl_pay = mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(amount) AS value_sum FROM transactions WHERE user_id='".$_SESSION['user_id']."' and status='paid'")); 
	$ttl_payout = $ttl_pay['value_sum'];
	
	$ttl_pen =  mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(amount) AS value_sum FROM transactions WHERE user_id='".$_SESSION['user_id']."' and status='pending'")); 
	$ttl_pending = $ttl_pen['value_sum'];
	
	$settings=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM settings WHERE id='1'"));
	
	if($ttl_pending==''){
		$ttl_pending=0;
	}
	
	if($ttl_payout==''){
		$ttl_payout=0;
	}
	
	$limit_amount=$settings['payout_limit'];
	if(isset($_POST['re'])){
		if($_POST['amount']>$logged_user['wallet']){
			$alert='<div class="alert alert-danger">Please Earn Money! you have $'.$logged_user['wallet'].'</div>';
		} else {
			if($_POST['amount']<$limit_amount){
				$alert='<div class="alert alert-danger">Minimun $'.$limit_amount.' is required</div>';
			} else {
				$amt=$_POST['amount'];
				$c=mysqli_query($conn,"INSERT INTO transactions (user_id,amount,date,status) VALUES ('".$logged_user['user_id']."','".$_POST['amount']."','".date("Y-m-d")."','pending')");
				if($c){
					mysqli_query($conn,"UPDATE users SET wallet = wallet - $amt WHERE user_id='".$logged_user['user_id']."'");
					$alert='<div class="alert alert-success"><i class="fa fa-check"></i>&nbsp;&nbsp;Amount $'.$amt.' is requsted</div>';
				} else {
					$alert='<div class="alert alert-danger">Somethis is wrong</div>';
				}
			}
		}
	}
?>
<html>
	<head>
		<title>Payment</title>
		<!-- meta tags-->
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Make your link safe using Link Protector" />
		<meta name="keywords" content="link, short, protector" />
		<meta name="author" content="Rohit Chauhan" />
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />
		<link rel="stylesheet" href="assets/fonts/css/font-awesome.min.css">
		<link rel="icon" href="favicon.png" sizes="16x16" type="image/png">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/jquery-1.9.1.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/bootstrap.bundle.min.js"></script>
	</head>
	<body class="bg-light">
		<?php include 'header.php';?>
		<div class="container">
		<br>
		<form action="" method="post">
		<?php echo $alert;?>
		<div class="card p-3">
			<h4><i class="fa fa-dollar"></i>&nbsp;Payment</h4>
			<hr>
			<div class="row">
				<div class="col">
					<div class="card bg-light p-3">
						<h6>Wallet</h6>
						<h2><?php echo $currency;?><?php echo round($logged_user['wallet'],4);?></h3>
					</div>
				</div>
				<div class="col">
					<div class="card bg-light p-3">
						<h6>Payouts</h6>
						<h2><?php echo $currency;?><?php echo $ttl_payout;?></h3>
					</div>
				</div>
				<div class="col">
					<div class="card bg-light p-3">
						<h6>Pending</h6>
					<h2><?php echo $currency;?><?php echo $ttl_pending;?></h3>
					</div>
				</div>
			</div>
			<br>
			<h5>Request Payment</h5>
			<hr>
			<label>Enter Amount (Min <?php echo $currency;?><?php echo $settings['payout_limit'];?>)</label>
			<form action="" method="">
			<div class="row">
				<div class="col-5">
				<input type="number" name="amount" class="form-control"/>
				</div>
				<div class="col">
					<input name="re" type="submit" class="btn btn-success" value="REQUEST"/>
				</div>
			</div>
			</form>
			<br>
			<hr>
			<label>Payment History</label>
				<div class="table-responsive@wide">
                <table class="table">
                  <thead class="table_head">
                    <tr class="table_row">
                      <th class="table_cell table_cell--head">Amount</th>
                      <th class="table_cell table_cell--head">Date</th>
                      <th class="table_cell table_cell--head">Status</th>
                    </tr>
                  </thead>

                  <tbody>
				      <?php
							 $query   = "select * from transactions where user_id='" . $logged_user['user_id'] . "' ORDER BY ID desc";
								$results = mysqli_query($conn, $query);
								while($row=mysqli_fetch_assoc($results)) {
								if ($row['status'] == 'paid') {
									$transtatus = 'success';
								} else if ($row['status'] == 'pending') {
									$transtatus = 'warning';
								} else {
									$transtatus = 'danger';
								}
								
								echo '
								 <td class="table_cell">'.$currency.''.$row['amount'].'</td>
								 <td class="table_cell">'.date("d M Y",strtotime($row['date'])).'</td>
								 <td class="table_cell"><span class="badge badge-' . $transtatus . '">' . strtoupper($row['status']) . '</span></td>
							  </tr>';
							}
						?>
                  </tbody>
                </table>
              </div>
		</div>
		<br>
		</form>
		<div class="modal fade" id="recordFilter">
  <div class="modal-dialog">
    <div class="modal-content">
<form action="" method="get">
      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Record Filter</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <label>Sort By</label>
		<select name="sort" class="form-control">
			<option value="asc">Ascending</option>
			<option value="desc">Dscending</option>
		</select>
		<br>
		<label>Sort Column</label>
		<select name="column" class="form-control">
			<option value="link_id">Link Name</option>
			<option value="date">Date</option>
		</select>
		<br>
		<label>Records</label>
		<select name="limit" class="form-control">
			<option value="10">10</option>
			<option value="25">25</option>
			<option value="50">50</option>
			<option value="100">100</option>
			<option value="250">250</option>
			<option value="500">500</option>
			<option value="1000">1000</option>
			<option value="2500">2500</option>
			<option value="5000">5000</option>
			<option value="10000">10000</option>
			<option value="9999999999999999">Show All Records</option>
		</select>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
       <input type="submit" name="sort_re" class="btn btn-success" value="SORT RECORD"/>
      </div>
</form>
    </div>
  </div>
</div>
		</div>
			<?php include 'footer.php';?>	
	</body>
</html>