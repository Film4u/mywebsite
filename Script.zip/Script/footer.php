<br>
	<?php
	if($check_ip>=2){
		echo '';
	} else {
		echo '
			<form id="insertformFoot" action="ad_click.php" method="post">
			<input type="hidden" name="ip" value="'.$users_ip.'"/>
			<div id="sendFoot">
				<div id="resultFoot">'.$ads['ads3'].'</h4>
			</div>
			</form>
		';
	}
?>
<br>
<div class="navbar navbar-light bg-dark">
<center><p class="text-light">&copy; 2019 </p></center>
</div>