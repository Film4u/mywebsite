<?php
error_reporting(0);
session_start();
$alert=NULL;
include '../config.php';

if(isset($_POST['adminlogin']))
{
     $admin_username=mysqli_real_escape_string($conn,$_POST['myusername']);
     $admin_password=mysqli_real_escape_string($conn,$_POST['mypassword']);

     $sql="SELECT * FROM admin WHERE username='$admin_username' AND password='$admin_password'";
     $result=mysqli_query($conn,$sql);
     $count=mysqli_num_rows($result);

     if($count==1)
     {
          $_SESSION["admin"]="$id";
		 header('location:dash.php');
     }
     else
     {
		 $alert='<div class="alert alert-danger">The username or password you entered is incorrect</div>';
     }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Admin Panel</title>
    <meta name="description" content="Neat">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="../assets/fonts/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/neat.min.css?v=1.0">
	<script src="assets/js/neat.min.js?v=1.0"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/jquery-1.9.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/bootstrap.bundle.min.js"></script>
    <link rel="apple-touch-icon" href="../apple-touch-icon.png">
    <link rel="shortcut icon" href="../favicon.png" type="image/x-icon">
    <!-- Stylesheet -->
  </head>
  <body>

    <div class="o-page o-page--center">
      <div class="o-page__card">
        <div class="c-card c-card--center">
          <span class="c-icon c-icon--large u-mb-small">
            <img src="../favicon.png" alt="Logo">
          </span>

          <h4 class="u-mb-medium">Welcome Admin :)</h4>
		  <?php echo $alert;?>
          <form action="" method="post">
            <div class="c-field">
              <label class="c-field__label">Username</label>
              <input class="c-input u-mb-small" type="text" placeholder="Username" name="myusername" required />
            </div>
            
            <div class="c-field">
              <label class="c-field__label">Password</label>
              <input class="c-input u-mb-small" type="password" placeholder="Password" name="mypassword" required />
            </div>
            <input type="submit" class="c-btn c-btn--fullwidth c-btn--info" name="adminlogin" value="Login">
          </form>
		  <br>
        </div>
      </div>
    </div>
    <!-- Main JavaScript -->
  </body>
</html>