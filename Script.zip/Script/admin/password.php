<?php
session_start();
$alert=NULL;

$alert=NULL;
if (isset($_SESSION['admin'])) {
    include '../config.php';
    $id = $_SESSION['admin'];
} else {
    echo "<script type='text/javascript'>
     window.location.href='index.php';
     </script>";
}

if(isset($_POST['password_update'])) {
		$ad_username=mysqli_real_escape_string($conn,$_POST['username']);
		$ad_password=mysqli_real_escape_string($conn,$_POST['password']);
        $dd=mysqli_query($conn, "UPDATE admin SET username='" . $ad_username . "', password='" . $ad_password . "' WHERE id='1'");
        if($dd){
			$alert='<div class="alert alert-success">
    <strong>Update Successful!</strong> Settings has been update.
  </div><meta http-equiv="refresh" content="2">';
		} else {
				$alert='<div class="alert alert-danger">
   Failed to Update
  </div><meta http-equiv="refresh" content="2">';
		}
}

$admin_data=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM admin WHERE id='1'"));
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Admin Password</title>
    <meta name="description" content="Neat">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="../assets/fonts/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/neat.min.css?v=1.0">
	<script src="assets/js/neat.min.js?v=1.0"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/jquery-1.9.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/bootstrap.bundle.min.js"></script>
    <link rel="apple-touch-icon" href="../apple-touch-icon.png">
    <link rel="shortcut icon" href="../favicon.png" type="image/x-icon">
  </head>
  <body>

    <div class="o-page">
    <?php include 'sidebar.php';?>
      <main class="o-page__content">
        <?php include 'header.php';?>

        <div class="container">
		<?php echo $alert;?>
          <h3>Username and Password Settings</h3>
		  <br>
		  <div class="c-card">
<form action="" method="post">
     <label>Admin Username</label>
	  <br>
      <input  type="text" class="form-control input-lg" name="username" value="<?php
echo $admin_data['username'];
?>"><br>
    <label>Admin Password</label>
	  <br>
      <input  type="text" class="form-control input-lg" name="password" value="<?php
echo $admin_data['password'];
?>"><br>
    <input type="submit" class="c-btn c-btn--warning" name="password_update" value="Update">
     </form>
		  </div>
        </div>
      </main>
    </div>

    <!-- Main JavaScript -->
    <script src="js/neat.min.js?v=1.0"></script>
  </body>
</html>