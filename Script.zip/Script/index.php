<?php
session_start();
	include 'config.php';
	$alert=NULL;
	$settings=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM settings WHERE id='1'"));
	$ads=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM ads WHERE id='1'"));
?>
<html>
	<head>
		<title><?php echo $settings['site_name'];?></title>
		<!-- meta tags-->
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Make your link safe using Link Protector" />
		<meta name="keywords" content="link, short, protector" />
		<meta name="author" content="Rohit Chauhan" />
		<meta property="og:title" content="<?php echo $settings['site_name'];?>" />
		<meta property="og:type" content="website" />
		<meta property="og:description" content="Protect your unlimited links and earn money via sharing link as per view. | "<?php echo $settings['site_name'];?> />
		<meta property="og:url" content="http://<?php echo $_SERVER['HTTP_HOST'];?>" />
		<meta property="og:image" content="http://<?php echo $_SERVER['HTTP_HOST'];?>/assets/img/og.png" />
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />
		<link rel="stylesheet" href="assets/fonts/css/font-awesome.min.css">
		<link rel="icon" href="favicon.png" sizes="16x16" type="image/png">
		<script src='https://www.google.com/recaptcha/api.js'></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/jquery-1.9.1.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/bootstrap.bundle.min.js"></script>
		<style>
			#text-url{width:80%;}
			#av-btn{margin-left:10%;}
			@media (max-width: 700px) { 
				#text-url{width:100%;}
				#av-btn{margin-left:0%;}
			}
		</style>
	</head>
	<body class="bg-light">
		<?php include 'header.php';?>
		<div class="container">
		<br>
		<center>
			<h3>Earn <i style="color:#ff9900;" class="fa fa-money"></i> via Protecting Link</h3>
			<p><i style="color:green;" class="fa fa-lock"></i> Protect your link in just one click</p>
		</center>
		<br>
		<form action="protected.php" method="post">
		<div class="card p-2 ">
		<br>
		<?php echo $alert;?>
			<center><h4>Paste Link URLs</h4>
		<br>	
				<textarea style="background:#ffffcc;" id="text-url" name="urls" onkeyup="text()" class="form-control" placeholder="Insert list of Urls"></textarea>
			</center>
			<br>
			<hr>
			<center><h5><i class="fa fa-cog"></i>&nbsp;Advance Settings</h5><center>
				<div style="text-align:left;" class="container p-3">
					<center>
					<div class="form-check-inline">
					  <label class="form-check-label">
						<span class="badge badge-success">Captcha: </span>
					  </label>
					</div>
					<div class="form-check-inline">
					  <label class="form-check-label">
						<input type="radio" class="form-check-input" name="captcha" value="on">On
					  </label>
					</div>
					<div class="form-check-inline">
					  <label class="form-check-label">
						<input type="radio" class="form-check-input" name="captcha" value="off" checked>Off
					  </label>
					</div>
					<br>
					<br>
				    <input style="background:#ffffcc;" id="text-url"  name="password" class="form-control" placeholder="Encryption Password">
				    <br>
				    <input style="background:#ffffcc;" id="text-url"  name="title" class="form-control" placeholder="Title">
					<br>
					<hr>
					<br>
					<button id="pro_btn" name="generate" style="width:180px;" class="btn btn-success"><i class="fa fa-lock"></i>&nbsp;&nbsp;PROTECT LINKS</button>
					<br>
					<br>
			<p>By uploading links to our site you agree to the <a href="#">Terms of use</a></p>
					</center>
				</div>
			<br>
		</div>
		</form>
		<br>
		</div>
			<?php include 'footer.php';?>	
	</body>
	<script>
		$('#insertformHead').submit(function(){
			return false;
		});
		$('#sendHead').click(function(){
			$.post(		
				$('#insertformHead').attr('action'),
				$('#insertformHead :input').serializeArray(),
				function(result){
					$('#resultHead').html(result);
				}
			);
		});
		
		$('#insertformFoot').submit(function(){
			return false;
		});
		$('#sendFoot').click(function(){
			$.post(		
				$('#insertformFoot').attr('action'),
				$('#insertformFoot :input').serializeArray(),
				function(result){
					$('#resultFoot').html(result);
				}
			);
		});
	</script>
	<script>
		document.getElementById("pro_btn").disabled=true;
		function text(){
			var text= document.getElementById("text-url").value;
			if(text==''){
				document.getElementById("pro_btn").disabled=true;
			} else {
				document.getElementById("pro_btn").disabled=false;
			}
		}
	</script>
</html>