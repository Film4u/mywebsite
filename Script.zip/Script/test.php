<?php
$string=md5("rohit");
echo $string;
echo '<br>';
echo '<br>';

$s=md5($string);
echo $s;
?>