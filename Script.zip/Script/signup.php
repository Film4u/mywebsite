<?php
	session_start();
	include 'config.php';
	$alert=NULL;
	
if(isset($_POST['signup'])){
	$username=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users WHERE username='".$_POST['username']."'"));
	$email=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users WHERE email='".$_POST['email']."'"));
	if($username==1){
		$alert='<div class="alert alert-danger">@'.$_POST['username'].' already used!</div>';
	}else if($email==1){
		$alert='<div class="alert alert-danger">Already Registered with '.$_POST['email'].'!</div>';
	} else {
			$password=mysqli_real_escape_string($conn,md5($_POST['password']));
			$if=mysqli_query($conn,"INSERT INTO users (`name`,`username`,`email`,`status`,`password`,`wallet`,`date`) VALUES ('".$_POST['name']."','".$_POST['username']."','".$_POST['email']."','active','".$password."','0','".date("Y-m-d")."')");
			if($if){
				 $users=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM users WHERE username='".$_POST['username']."'"));
				 $_SESSION['user_id']=$users['user_id'];
				 //$alert='<div class="alert alert-success">Successs!</div>';
				header('location:user.php');
			} else {
				$alert='<div class="alert alert-danger">Invalid Data!</div>';
			}
	}
}
	$settings=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM settings WHERE id='1'"));
	$ads=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM ads WHERE id='1'"));
?>
<html>
	<head>
		<title>Signup | <?php echo $settings['site_name'];?></title>
		<!-- meta tags-->
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Make your link safe using <?php echo $settings['site_name'];?>" />
		<meta name="keywords" content="link, short, protector" />
		<meta name="author" content="Rohit Chauhan" />
		<meta property="og:title" content="Signup | <?php echo $settings['site_name'];?>" />
		<meta property="og:type" content="website" />
		<meta property="og:description" content="Protect your unlimited links and earn money via sharing link as per view. | "<?php echo $settings['site_name'];?> />
		<meta property="og:url" content="http://<?php echo $_SERVER['HTTP_HOST'];?>" />
		<meta property="og:image" content="http://<?php echo $_SERVER['HTTP_HOST'];?>/assets/img/og.png" />		<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />
		<link rel="stylesheet" href="assets/fonts/css/font-awesome.min.css">
		<link rel="icon" href="favicon.png" sizes="16x16" type="image/png">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/jquery-1.9.1.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/bootstrap.bundle.min.js"></script>
	</head>
	<body class="bg-light">
		<?php include 'header.php';?>
		<div class="container">
		<br>
		<form action="" method="post">
		<?php echo $alert;?>
		<div class="card p-3">
			<h4>SIGNUP ACCOUNT</h4>
			<hr>
			<div class="row">
				<div style="text-align:right;" class="col-2">
					<h6>Name:</h6>
				</div>
				<div class="col-5">
					<input type="text" name="name" class="form-control" placeholder="Enter Your Name"/>
				</div>
			</div>
			<br>
			<div class="row">
				<div style="text-align:right;" class="col-2">
					<h6>Username:</h6>
				</div>
				<div class="col-5">
					<input type="text" id="nosp" name="username" class="form-control" placeholder="Enter Your Username"/>
				</div>
			</div>
			<br>
			<div class="row">
				<div style="text-align:right;" class="col-2">
					<h6>Email:</h6>
				</div>
				<div class="col-5">
					<input type="email" id="nosp" name="email" class="form-control" Placeholder="Enter Your Email"/>
				</div>
			</div>
			<br>
			<div class="row">
				<div style="text-align:right;" class="col-2">
					<h6>Password:</h6>
				</div>
				<div class="col-5">
					<input type="password" name="password" class="form-control" placeholder="Enter Your Password"/>
				</div>
			</div>
			<br>
			<div class="row">
				<div style="text-align:right;" class="col-2">
				</div>
				<div class="col-5">
					<input type="submit" name="signup" class="btn btn-success" value="SIGN UP"/>
				</div>
			</div>
			<br>
			<div class="row">
				<div style="text-align:right;" class="col-2">
				</div>
				<div class="col-5">
					<p><i class="fa fa-lock"></i> &nbsp;Forget Password? <a data-toggle="modal" data-target="#forget" href="#">Click Here</a></p>
				</div>
			</div>
			<br>
		</div>
		<br>
		</form>
		<div class="modal fade" id="forget">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Forget Password</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
					<form action="reset_password.php" method="post" id="insertform">
						<input type="email" name="email" class="form-control" Placeholder="Enter Your Regitered Email"/>
						<br>
						<input style="width:100%;" name="reset" type="submit" value="Forget" id="insert" class="btn btn-danger"/>
						<br>
						<br>
						<div id="result"></div>
					</form>
					
      </div>

    </div>
  </div>
</div>
		</div>
			<?php include 'footer.php';?>	
	</body>
	  	<script>
$('#insertform').submit(function(){
	return false;
});
$('#insert').click(function(){
	$.post(		
		$('#insertform').attr('action'),
		$('#insertform :input').serializeArray(),
		function(result){
			$('#result').html(result);
		}
	);
});

$("input#nosp").on({
  keydown: function(e) {
    if (e.which === 32)
      return false;
  },
  change: function() {
    this.value = this.value.replace(/\s/g, "");
  }
});
</script>
<script>
			$('#insertformHead').submit(function(){
			return false;
		});
		$('#sendHead').click(function(){
			$.post(		
				$('#insertformHead').attr('action'),
				$('#insertformHead :input').serializeArray(),
				function(result){
					$('#resultHead').html(result);
				}
			);
		});
		
		$('#insertformFoot').submit(function(){
			return false;
		});
		$('#sendFoot').click(function(){
			$.post(		
				$('#insertformFoot').attr('action'),
				$('#insertformFoot :input').serializeArray(),
				function(result){
					$('#resultFoot').html(result);
				}
			);
		});
	</script>
</html>