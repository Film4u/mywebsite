<?php
	session_start();
	include 'config.php';
	$alert=NULL;
	$link_id=$_GET['id'];
	$links=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM links WHERE link_id='".$link_id."'"));
	$users=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM users WHERE user_id='".$links['user_id']."'"));
	$settings=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM settings WHERE id='1'"));
	$ads=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM ads WHERE id='1'"));
	$links_st=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM links WHERE link_id='".$link_id."'"));
	if(!$links_st>=1){
		header('location:/');
	}
	$earn_lmt=$settings['earn_limit'];
	$earn=$earn_lmt/1000; //>> Earn/Per Click
	
	if($links['title']==''){
		$title=$settings['site_name'];
	} else {
		$title=$links['title'];
	}
	if($links['user_id']==''){
		$user='Anonymous';
	} else {
		$user=$users['name'];
	}
	$ip_add=$_SERVER['REMOTE_ADDR'];
	$check_ip=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM views WHERE link_id='".$link_id."' and ip_add='".$ip_add."'"));
	if(!$check_ip>=1){
		mysqli_query($conn,"INSERT INTO views (link_id,ip_add) VALUES ('".$link_id."','".$ip_add."')");
		mysqli_query($conn,"UPDATE users SET wallet = wallet + $earn WHERE user_id='".$links['user_id']."'");
	}
	$views=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM views WHERE link_id='".$link_id."'"));
	
	if(isset($_POST['saveit'])){

		$newFileName = 'files/'.$link_id.".txt";
		$newFileContent = $links['urls'];
		$filename=file_put_contents($newFileName, $newFileContent);
		
		header("Cache-Control: public");
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$link_id.txt");
		header("Content-Type: application/txt");
		header("Content-Transfer-Encoding: binary");
		
		// Read the file
		readfile($newFileName);
		exit;
	}
	
	if(isset($_POST['unlock'])){
		if($_POST['pass']==$links['password']){
		$links['pass']='no';
		$alert='<div class="alert alert-success"><i class="fa fa-check"></i>&nbsp;Currect Encryption Key, Links unlocked!</div>"';
		} else {
			$links['pass']='yes';
			$alert='<div class="alert alert-danger"><i class="fa fa-remove"></i>&nbsp;Incorrect Encyption Key!</div>"';
		}
	}
?>
<html>
	<head>
		<title><?php echo $title;?></title>
		<!-- meta tags-->
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Make your link safe using Link Protector" />
		<meta name="keywords" content="link, short, protector" />
		<meta name="author" content="Rohit Chauhan" />
		<meta name="robots" content="nofollow, noindex" />
		<meta property="og:title" content="<?php echo $settings['site_name'];?>" />
		<meta property="og:type" content="website" />
		<meta property="og:description" content="Protect your unlimited links and earn money via sharing link as per view. | "<?php echo $settings['site_name'];?> />
		<meta property="og:url" content="http://<?php echo $_SERVER['HTTP_HOST'];?>" />
		<meta property="og:image" content="http://<?php echo $_SERVER['HTTP_HOST'];?>/assets/img/og.png" />
		<link rel="stylesheet" href="../assets/css/bootstrap.min.css" type="text/css" />
		<link rel="stylesheet" href="../assets/fonts/css/font-awesome.min.css">
		<link rel="icon" href="../favicon.png" sizes="16x16" type="image/png">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="../assets/js/popper.min.js"></script>
		<script src="../assets/js/jquery-1.9.1.min.js"></script>
		<script src="../assets/js/bootstrap.min.js"></script>
		<script src="../assets/js/bootstrap.bundle.min.js"></script>
		<style>
			#text-url{width:80%;}
			#av-btn{margin-left:10%;}
			@media (max-width: 700px) { 
				#text-url{width:100%;}
				#av-btn{margin-left:0%;}
			}
		</style>
	</head>
	<body class="bg-light">
		<?php include 'header.php';?>
		<div class="container">
		<br>
		
			<div class="alert alert-success"><i class="fa fa-unlock"></i>&nbsp;Links Unlocked Now. You can Download your files/video/music from "SAVE IT" button.</div>
		<div class="card p-4">
		<p>Download Link Protector helps you offer downloads in a safe and secure way. You can still offer your downloads the way you have been doing till now. However now your downloads can not be copied or distributed through emails, forums and social networking websites.</p>
		<?php
	if($check_ip>=2){
		echo '';
	} else {
		echo '
			<form id="insertformV" action="ad_click.php" method="post">
			<input type="hidden" name="ip" value="'.$users_ip.'"/>
			<div id="sendV">
				<div id="resultV">'.$ads['ads2'].'</h4>
			</div>
			</form>
		';
	}
?>
			<hr>
			<?php echo $alert;?>
			<br>
			<center>
			<div id="text-url" class="card p-2" style="text-align:left;background:#ffffcc;">
			<?php 
			if($links['status']=='blocked'){
					echo '<div class="alert alert-danger"><i class="fa fa-ban"></i>&nbsp;Blocked</div>';
			} else if($links['status']=='removed'){
					echo '<div class="alert alert-danger"><i class="fa fa-remove"></i>&nbsp;Link Removed</div>';
			} else {
				
				if($links['pass']=='yes'){
					echo '<div class="alert alert-warning"><i class="fa fa-lock"></i>&nbsp;Link is Protected, Enter Encyption Key to Show Links.</div>
							<center><form action="" method="post">
								<label>Enter Encryption Key</label>
								<input name="pass" class="form-control" placeholder="Enter Key"/>
								<br>
								<input name="unlock" class="btn btn-dark" type="submit" value="UNLOCK"/>
							</form>
							</center>
					';
				} else {
			
				$url = '/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/';   
				$string= preg_replace($url, '<a style="font-size:18px;" href="$0" target="_blank" title="$0">$0</a>', $links['urls']);
				echo $string;
				
				}
			}
				?>
			</div>
			</center>
			<br>
		<div class="row">
			<div class="col">
				<center><span class="badge badge-dark">Created by</span> <?php echo $user;?></center>
			</div>
			<div class="col">
				<center><span class="badge badge-dark">Created On</span> 5 Jan 2019</center>
			</div>
			<div class="col">
				<center><span class="badge badge-dark">View</span> <?php echo $views;?></center>
			</div>
		</div>
		<br>	
			<center>
			<form action="" method="post">
			<?php 
				if($links['pass']=='yes' || $links['status']=='blocked' || $links['status']=='removed'){
					echo '';
				} else {
					echo '<button name="saveit" style="width:200px;" class="btn btn-primary"><i class="fa fa-save"></i>&nbsp;&nbsp;SAVE IT</button>';
				}
				?>
			</form>
			</center>
		<br>		
		<hr>
		<p>We provides one of the finest Link Protecting services in the world. Our Team Experts have created our very own Link Sharing Algorithm (implemented carefully) to maintain your Links at Max Speed with the alternative of consuming much more and inappropriate Resources. We at JioLink always care for our users and protect their information and all the services are ascendable referred to your benefit like you can easily add more links and edit without putting a notable impact on yours mind.</p>
		</div>
		<br>
		</div>
			<?php include 'footer.php';?>	
	</body>
	<script>
		$('#insertformV").submit(function(){
			return false;
		});
		$('#sendV').click(function(){
			$.post(		
				$('#insertformV').attr('action'),
				$('#insertformV :input').serializeArray(),
				function(result){
					$('#resultV').html(result);
				}
			);
		});
			$('#insertformHead').submit(function(){
			return false;
		});
		$('#sendHead').click(function(){
			$.post(		
				$('#insertformHead').attr('action'),
				$('#insertformHead :input').serializeArray(),
				function(result){
					$('#resultHead').html(result);
				}
			);
		});
		
		$('#insertformFoot').submit(function(){
			return false;
		});
		$('#sendFoot').click(function(){
			$.post(		
				$('#insertformFoot').attr('action'),
				$('#insertformFoot :input').serializeArray(),
				function(result){
					$('#resultFoot').html(result);
				}
			);
		});
	</script>
</html>